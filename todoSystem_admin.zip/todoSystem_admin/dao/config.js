const config ={
    connectionLimit: 10,
    multipleStatements: true,
    host: '127.0.0.1',
    user: 'root',
    password: '3234853521.',
    database: 'todosystem'
}
module.exports = config
